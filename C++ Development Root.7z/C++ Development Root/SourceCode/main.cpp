#include <iostream>

int main()
{
  std::cout << "C++ Rocks!\n";
}
